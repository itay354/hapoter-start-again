import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useContent } from './ContentManager';
import { useLanguage } from '../contexts/LanguageContext';
import ExampleCard from './ExampleCard';
import LogoCarousel from './LogoCarousel';

const Examples: React.FC = () => {
  const { content } = useContent();
  const { direction, t } = useLanguage();
  const [activeTab, setActiveTab] = useState('images');
  const [dividerPositions, setDividerPositions] = useState<{ [key: string]: number }>({});
  
  // יצירת EXAMPLES_DATA דינמי שמשתמש בתמונות מה-ContentManager
  const EXAMPLES_DATA = useMemo(() => ({
    // טאב תמונות - עודכן לתמונות Tanti Model
    images: [
      {
        before: content.images.image1 || "/assets/tanti model before.jpg",
        after: content.images.image2 || "/assets/tanti model after.jpg",
        title: t('examples.fashion.title') || 'Same Clothes - Model Change on Demand'
      },
      {
        before: "/assets/Slide3.PNG",
        after: "/assets/image copy copy.png", 
        title: t('examples.presentation.title') || "Business Presentation - Professional Enhancement"
      }
    ],
    // טאב וידאו - עם וידאואים מקומיים מאופטמים
    videos: [
      {
        before: content.images.image1 || "/assets/tanti model before.jpg",
        after: content.images.image2 || "/assets/tanti model after.jpg",
        title: t('examples.fashion.ai') || "Fashion AI Simulation - Tanti Model Technology",
        type: "video",
        videoUrl: "/videos/first-model.mp4",
        poster: "/assets/tanti model after.jpg"
      },
      {
        before: content.images.before3 || "/assets/be there - before.png",
        after: content.images.after3 || "/assets/be there after.png",
        title: t('examples.animation') || "Image to Video Animation - AI Animation",
        type: "video",
        videoUrl: "/videos/second better hapoter fal-ai-veo3.mp4",
        poster: "/assets/generated_image (1).png"
      },
      {
        before: "https://images.pexels.com/photos/4019768/pexels-photo-4019768.jpeg?auto=compress&cs=tinysrgb&w=800",
        after: "https://images.pexels.com/photos/4019768/pexels-photo-4019768.jpeg?auto=compress&cs=tinysrgb&w=800",
        title: t('examples.gary.video') || "Gary - Professional Fitness Training Video",
        type: "video",
        videoUrl: "/videos/garry first video ad.mp4",
        poster: "/assets/logo-with-mockup-garry.jpg"
      },
      {
        before: "https://images.pexels.com/photos/3184287/pexels-photo-3184287.jpeg?auto=compress&cs=tinysrgb&w=800",
        after: "https://images.pexels.com/photos/3184287/pexels-photo-3184287.jpeg?auto=compress&cs=tinysrgb&w=800",
        title: t('examples.pixelsolver.demo') || "PixelSolver - AI Technology Demo",
        type: "video",
        videoUrl: "/videos/doogmanit-video.mp4",
        poster: "/assets/generated_image (2).png"
      }
    ],
    // טאב יצירת מוקאפים - משתמש בתמונות דינמיות מ-ContentManager
    mockups: [
      {
        before: content.images.before1 || "/assets/player.jpg",
        after: content.images.after1 || "/assets/generated_image.png",
        title: t('examples.mockup.creation') || "Mockup Creation"
      },
      // הדוגמה של גארי - עם המוקאפ המקורי עם המשקולות
      {
        before: "/assets/logo-transparent-garry.svg",
        after: "/assets/logo-with-mockup-garry.jpg",
        title: t('examples.gary.logo') || "Logo Design and Implementation as Dumbbell Mockup"
      },
      // הדוגמה של Be There - עם הקובץ החדש שהעלית
      {
        before: content.images.before3 || "/assets/be there - before.png",
        after: content.images.after3 || "/assets/be there after.png",
        title: t('examples.bethere') || "HR System - From Sketch to Mockup"
      }
    ],
    // טאב לוגואים - עובד עם הקרוסלה
    logos: []
  }), [content.images, t]); // תלוי בתמונות מה-content ובתרגומים
  
  // Initialize divider positions - רק פעם אחת כשה-EXAMPLES_DATA משתנה
  useEffect(() => {
    const initialPositions: { [key: string]: number } = {};
    
    Object.keys(EXAMPLES_DATA).forEach(category => {
      if (category !== 'logos') {
        EXAMPLES_DATA[category as keyof typeof EXAMPLES_DATA].forEach((example, index) => {
          const key = `${category}-${index}`;
          initialPositions[key] = 50; // Start at middle (50%)
        });
      }
    });
    
    setDividerPositions(initialPositions);
  }, [EXAMPLES_DATA]); // תלוי ב-EXAMPLES_DATA

  // Handle divider position change - useCallback למניעת re-creation
  const handleDividerChange = useCallback((category: string, index: number, position: number) => {
    const key = `${category}-${index}`;
    setDividerPositions(prev => ({
      ...prev,
      [key]: position
    }));
  }, []);

  // Memoize current examples to prevent unnecessary re-renders
  const currentExamples = useMemo(() => {
    return EXAMPLES_DATA[activeTab as keyof typeof EXAMPLES_DATA] || [];
  }, [activeTab, EXAMPLES_DATA]);

  return (
    <section id="examples" className="py-16 md:py-24 bg-peach-100 relative overflow-hidden">
      {/* Geometric elements */}
      <div className="absolute top-0 left-0 w-full h-16 bg-royal-600 opacity-10"></div>
      <div className="absolute bottom-0 right-0 w-full h-16 bg-coral-500 opacity-10"></div>
      <div className={`absolute top-40 w-32 h-32 bg-royal-600 rounded-full opacity-10 ${
        direction === 'rtl' ? 'left-10' : 'right-10'
      }`}></div>
      <div className={`absolute bottom-40 w-32 h-32 bg-coral-500 rounded-full opacity-10 ${
        direction === 'rtl' ? 'right-10' : 'left-10'
      }`}></div>
      
      {/* 3D Isometric Shapes */}
      <div className={`absolute top-1/4 w-24 h-24 bg-coral-300 transform rotate-45 skew-x-12 skew-y-12 opacity-30 ${
        direction === 'rtl' ? 'right-10' : 'left-10'
      }`}></div>
      <div className={`absolute top-1/4 w-24 h-24 bg-royal-300 transform rotate-45 skew-x-12 skew-y-12 opacity-20 ${
        direction === 'rtl' ? 'right-16' : 'left-16'
      }`}></div>
      <div className={`absolute top-1/4 w-24 h-24 bg-sky-200 transform rotate-45 skew-x-12 skew-y-12 opacity-10 ${
        direction === 'rtl' ? 'right-22' : 'left-22'
      }`}></div>
      
      {/* 3D Spheres with gradients */}
      <div className={`absolute bottom-1/4 w-40 h-40 rounded-full opacity-20 ${
        direction === 'rtl' ? 'left-10' : 'right-10'
      }`} 
           style={{background: 'radial-gradient(circle, rgba(234,158,140,0.4) 0%, rgba(234,158,140,0) 70%)'}}></div>
      <div className={`absolute bottom-1/4 w-60 h-60 rounded-full opacity-20 ${
        direction === 'rtl' ? 'left-20' : 'right-20'
      }`}
           style={{background: 'radial-gradient(circle, rgba(79,84,255,0.3) 0%, rgba(79,84,255,0) 70%)'}}></div>
           
      {/* 3D Floating cubes */}
      <div className={`absolute top-1/3 w-16 h-16 bg-coral-200 transform rotate-45 skew-x-12 skew-y-12 opacity-30 animate-float ${
        direction === 'rtl' ? 'right-10' : 'left-10'
      }`} style={{animationDelay: '0.7s'}}></div>
      <div className={`absolute bottom-1/3 w-12 h-12 bg-coral-200 transform rotate-45 skew-x-12 skew-y-12 opacity-30 animate-float ${
        direction === 'rtl' ? 'left-10' : 'right-10'
      }`} style={{animationDelay: '1.4s'}}></div>
      
      {/* 3D Cylinders */}
      <div className={`absolute top-1/4 w-20 h-8 bg-sky-200 rounded-full opacity-30 ${
        direction === 'rtl' ? 'right-10' : 'left-10'
      }`}></div>
      <div className={`absolute top-1/4 w-20 h-24 bg-sky-200 opacity-20 transform translate-y-4 ${
        direction === 'rtl' ? 'right-10' : 'left-10'
      }`}></div>
      <div className={`absolute top-1/4 w-20 h-8 bg-sky-200 rounded-full opacity-30 transform translate-y-28 ${
        direction === 'rtl' ? 'right-10' : 'left-10'
      }`}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center mb-16">
          <span className="text-coral-600 font-medium mb-2 block">{t('examples.label')}</span>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {t('examples.title')}
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {t('examples.description')}
          </p>
        </div>

        <div className="flex justify-center mb-10">
          <div className={`flex bg-gray-100 p-1 rounded-lg relative max-w-full overflow-x-auto scrollbar-hide ${
            direction === 'rtl' ? 'space-x-2 space-x-reverse' : 'space-x-2'
          }`}>
            {/* 3D Tab effect */}
            <div className="absolute inset-0 bg-royal-200 opacity-10 rounded-lg transform -rotate-1"></div>
            <div className="absolute inset-0 bg-coral-200 opacity-10 rounded-lg transform rotate-1"></div>
            
            <button 
              className={`relative z-10 px-6 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                activeTab === 'images' 
                  ? 'bg-white text-royal-600 shadow-sm' 
                  : 'text-gray-600 hover:text-royal-600'
              }`}
              onClick={() => setActiveTab('images')}
            >
              {t('examples.tabs.images')}
            </button>
            <button 
              className={`relative z-10 px-6 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                activeTab === 'videos' 
                  ? 'bg-white text-royal-600 shadow-sm' 
                  : 'text-gray-600 hover:text-royal-600'
              }`}
              onClick={() => setActiveTab('videos')}
            >
              {t('examples.tabs.videos')}
            </button>
            <button 
              className={`relative z-10 px-6 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                activeTab === 'mockups' 
                  ? 'bg-white text-royal-600 shadow-sm' 
                  : 'text-gray-600 hover:text-royal-600'
              }`}
              onClick={() => setActiveTab('mockups')}
            >
              <span className="text-sm md:text-base">{t('examples.tabs.mockups')}</span>
            </button>
            <button 
              className={`relative z-10 px-6 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                activeTab === 'logos' 
                  ? 'bg-white text-royal-600 shadow-sm' 
                  : 'text-gray-600 hover:text-royal-600'
              }`}
              onClick={() => setActiveTab('logos')}
            >
              <span className="text-sm md:text-base">{t('examples.tabs.logos')}</span>
            </button>
          </div>
        </div>

        {/* תוכן הטאבים */}
        {activeTab === 'logos' ? (
          <div className="max-w-4xl mx-auto">
            <LogoCarousel />
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {currentExamples.map((example, index) => {
              const exampleKey = `${activeTab}-${index}`;
              const dividerPosition = dividerPositions[exampleKey] || 50;
              
              // וידאו מיוחד עבור דוגמאות וידאו - עכשיו עם וידאואים מקומיים מאופטמים
              if (activeTab === 'videos' && example.type === 'video') {
                return (
                  <div 
                    key={exampleKey}
                    className="bg-white rounded-xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 animate-slide-up relative"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    {/* 3D Card effects */}
                    <div className="absolute -top-4 -right-4 w-full h-full bg-royal-200 opacity-0 hover:opacity-10 transition-opacity rounded-xl transform hover:rotate-1"></div>
                    <div className="absolute -bottom-4 -left-4 w-full h-full bg-coral-200 opacity-0 hover:opacity-10 transition-opacity rounded-xl transform hover:-rotate-1"></div>
                    
                    <div className="p-6 relative">
                      {/* כותרת הווידאו */}
                      {example.title && (
                        <h3 className="text-xl font-bold text-gray-900 mb-4">{example.title}</h3>
                      )}
                      
                      <div className="relative w-full aspect-video overflow-hidden rounded-lg bg-gray-100">
                        {/* 3D frame effect */}
                        <div className="absolute -top-2 -right-2 w-full h-full bg-royal-200 opacity-0 group-hover:opacity-10 transition-opacity rounded-lg transform group-hover:rotate-1"></div>
                        <div className="absolute -bottom-2 -left-2 w-full h-full bg-coral-200 opacity-0 group-hover:opacity-10 transition-opacity rounded-lg transform group-hover:-rotate-1"></div>
                        
                        {/* וידאו מקומי מאופטם */}
                        <video
                          className="w-full h-full object-cover rounded-lg"
                          controls
                          preload="metadata"
                          poster={example.poster}
                          loading="lazy"
                          playsInline
                          muted
                          onError={(e) => {
                            console.error(`Failed to load video: ${example.videoUrl}`);
                            const target = e.target as HTMLVideoElement;
                            target.style.display = 'none';
                            // יצירת תמונת fallback
                            const fallbackImg = document.createElement('img');
                            fallbackImg.src = example.poster || "/assets/generated_image (1).png";
                            fallbackImg.className = "w-full h-full object-cover rounded-lg";
                            fallbackImg.alt = example.title || "Video not available";
                            target.parentNode?.appendChild(fallbackImg);
                          }}
                        >
                          <source src={example.videoUrl} type="video/mp4" />
                          {/* Fallback message */}
                          <div className="flex items-center justify-center h-full bg-gray-100">
                            <div className="text-center">
                              <div className="text-gray-500 mb-2">הווידאו לא זמין</div>
                              <img 
                                src={example.poster || "/assets/generated_image (1).png"} 
                                alt={example.title || "Video thumbnail"}
                                className="max-w-full max-h-full object-contain"
                              />
                            </div>
                          </div>
                        </video>
                      </div>
                    </div>
                  </div>
                );
              }
              
              return (
                <ExampleCard 
                  key={exampleKey}
                  example={example}
                  activeTab={activeTab}
                  index={index}
                  dividerPosition={dividerPosition}
                  onDividerPositionChange={(position) => handleDividerChange(activeTab, index, position)}
                />
              );
            })}
          </div>
        )}

        <div className="text-center mt-12">
          <p className="text-lg text-gray-600 mb-6">{t('examples.need')}</p>
          <a 
            href="#contact" 
            className="inline-block bg-coral-500 hover:bg-coral-600 text-white font-medium px-8 py-3 rounded-lg transition-colors relative"
          >
            {/* 3D Button effect */}
            <div className="absolute inset-0 bg-coral-600 opacity-0 hover:opacity-30 rounded-lg transform translate-y-1"></div>
            <span className="relative">{t('examples.cta')}</span>
          </a>
        </div>
      </div>
    </section>
  );
};

export default Examples;